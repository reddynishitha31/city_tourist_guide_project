package city;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.ImageIcon;

public class H3 {

	private JFrame frame;
	private JTextField textField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					H3 window = new H3();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public H3() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setIconImage(Toolkit.getDefaultToolkit().getImage("C:\\Users\\reddy\\Pictures\\Screenshots\\sru.png"));
		frame.setBounds(100, 100, 594, 421);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblBirlaMandir = new JLabel("Birla Mandir");
		lblBirlaMandir.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblBirlaMandir.setBounds(222, 20, 113, 15);
		frame.getContentPane().add(lblBirlaMandir);
		
		JLabel lblBirlaMandirIs = new JLabel("Birla Mandir is a Hindu temple, built on a 280 feet high hillock called Naubath Pahad on a 13 acres");
		lblBirlaMandirIs.setBounds(10, 45, 558, 13);
		frame.getContentPane().add(lblBirlaMandirIs);
		
		JLabel lblPlotInHyderabad = new JLabel("plot in Hyderabad.  The construction took 10 years and was opened in 1976 by Swami ");
		lblPlotInHyderabad.setBounds(10, 68, 558, 13);
		frame.getContentPane().add(lblPlotInHyderabad);
		
		JLabel lblRanganathanandaOfRamakrishna = new JLabel("Ranganathananda of Ramakrishna Mission.");
		lblRanganathanandaOfRamakrishna.setBounds(10, 91, 558, 13);
		frame.getContentPane().add(lblRanganathanandaOfRamakrishna);
		
		JLabel lblNewLabel_3_1_1 = new JLabel("Location:");
		lblNewLabel_3_1_1.setBounds(122, 125, 68, 13);
		frame.getContentPane().add(lblNewLabel_3_1_1);
		
		JLabel lblNewLabel_4_1 = new JLabel("Crowd:");
		lblNewLabel_4_1.setBounds(122, 149, 45, 13);
		frame.getContentPane().add(lblNewLabel_4_1);
		
		JLabel lblNewLabel_5_1 = new JLabel("Rating:");
		lblNewLabel_5_1.setBounds(122, 169, 45, 20);
		frame.getContentPane().add(lblNewLabel_5_1);
		
		JLabel lblNewLabel_9_2_1_3 = new JLabel("Feedback:");
		lblNewLabel_9_2_1_3.setBounds(122, 199, 67, 21);
		frame.getContentPane().add(lblNewLabel_9_2_1_3);
		
		JLabel lblNewLabel_9_2_1 = new JLabel("Hyderadab");
		lblNewLabel_9_2_1.setBounds(268, 125, 67, 21);
		frame.getContentPane().add(lblNewLabel_9_2_1);
		
		JLabel lblNewLabel_9_2_1_1 = new JLabel("average");
		lblNewLabel_9_2_1_1.setBounds(268, 149, 67, 21);
		frame.getContentPane().add(lblNewLabel_9_2_1_1);
		
		JLabel lblNewLabel_9_2_1_2 = new JLabel("4.7/5");
		lblNewLabel_9_2_1_2.setBounds(268, 173, 67, 21);
		frame.getContentPane().add(lblNewLabel_9_2_1_2);
		
		textField = new JTextField();
		textField.setColumns(10);
		textField.setBounds(260, 200, 75, 41);
		frame.getContentPane().add(textField);
		
		JButton btnNewButton_2 = new JButton("Submit");
		btnNewButton_2.setFont(new Font("Tahoma", Font.PLAIN, 9));
		btnNewButton_2.setBounds(260, 251, 75, 21);
		frame.getContentPane().add(btnNewButton_2);
		
		JButton btnNewButton_1_1 = new JButton("Back");
		btnNewButton_1_1.setBounds(70, 309, 75, 21);
		frame.getContentPane().add(btnNewButton_1_1);
		
		JLabel lblNewLabel_10_1 = new JLabel("");
		lblNewLabel_10_1.setIcon(new ImageIcon("C:\\Users\\reddy\\Pictures\\Saved Pictures\\b1.jpg"));
		lblNewLabel_10_1.setBounds(395, 125, 150, 102);
		frame.getContentPane().add(lblNewLabel_10_1);
		frame.setVisible(true);
		
		btnNewButton_1_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frame.getContentPane().setVisible(false);
				frame.dispose();
				h.main(null);
			}
		});

		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JOptionPane.showMessageDialog(null,"Feedback Success");
			}
		});
		
	}

}
