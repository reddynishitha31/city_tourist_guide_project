package city;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JButton;
import java.awt.BorderLayout;
import javax.swing.JLabel;

public class NextFrame {

	private JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					NextFrame window = new NextFrame();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public NextFrame() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 493, 359);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Bhadrakali\r\n");
		lblNewLabel.setBounds(35, 55, 108, 21);
		frame.getContentPane().add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Rating:4.4/5");
		lblNewLabel_1.setBounds(35, 76, 86, 18);
		frame.getContentPane().add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Ramappa");
		lblNewLabel_2.setBounds(263, 59, 86, 13);
		frame.getContentPane().add(lblNewLabel_2);
		
		JLabel lblNewLabel_1_1 = new JLabel("Rating:4.4/5");
		lblNewLabel_1_1.setBounds(263, 76, 86, 18);
		frame.getContentPane().add(lblNewLabel_1_1);
		
		JButton btnNewButton = new JButton("call");
		btnNewButton.setBounds(35, 104, 68, 18);
		frame.getContentPane().add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("call");
		btnNewButton_1.setBounds(266, 103, 68, 18);
		frame.getContentPane().add(btnNewButton_1);
		
		JButton btnNewButton_1_1 = new JButton("maps");
		btnNewButton_1_1.setBounds(35, 132, 68, 18);
		frame.getContentPane().add(btnNewButton_1_1);
		
		JButton btnNewButton_1_1_1 = new JButton("maps");
		btnNewButton_1_1_1.setBounds(266, 131, 68, 18);
		frame.getContentPane().add(btnNewButton_1_1_1);
		
		JButton btnNewButton_2 = new JButton("more");
		btnNewButton_2.setBounds(35, 160, 68, 18);
		frame.getContentPane().add(btnNewButton_2);
		
		JButton btnNewButton_2_1 = new JButton("more");
		btnNewButton_2_1.setBounds(266, 159, 68, 18);
		frame.getContentPane().add(btnNewButton_2_1);
		frame.setVisible(true);	
	}
}
