package city;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.ImageIcon;
import java.awt.Toolkit;

public class k {

	private JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					k window = new k();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public k() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setIconImage(Toolkit.getDefaultToolkit().getImage("C:\\Users\\reddy\\Pictures\\Screenshots\\sru.png"));
		frame.setBounds(100, 100, 714, 501);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Karimnagar");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel.setBounds(313, 20, 79, 39);
		frame.getContentPane().add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Lower Manair Dam");
		lblNewLabel_1.setBounds(33, 90, 122, 26);
		frame.getContentPane().add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Rating:4/5");
		lblNewLabel_2.setBounds(53, 126, 73, 13);
		frame.getContentPane().add(lblNewLabel_2);
		
		JButton btnNewButton = new JButton("Call");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnNewButton.setBounds(46, 152, 66, 21);
		frame.getContentPane().add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("More");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnNewButton_1.setBounds(46, 183, 66, 21);
		frame.getContentPane().add(btnNewButton_1);
		
		JLabel lblNewLabel_3 = new JLabel("");
		lblNewLabel_3.setIcon(new ImageIcon("C:\\Users\\reddy\\Downloads\\ls.jpg"));
		lblNewLabel_3.setBounds(153, 104, 140, 100);
		frame.getContentPane().add(lblNewLabel_3);
		
		JLabel lblNewLabel_4 = new JLabel("Elgandal Fort");
		lblNewLabel_4.setBounds(396, 97, 107, 13);
		frame.getContentPane().add(lblNewLabel_4);
		
		JLabel lblNewLabel_5 = new JLabel("Rating:4.3/5");
		lblNewLabel_5.setBounds(396, 126, 79, 13);
		frame.getContentPane().add(lblNewLabel_5);
		
		JButton btnNewButton_2 = new JButton("Call");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnNewButton_2.setBounds(396, 152, 66, 21);
		frame.getContentPane().add(btnNewButton_2);
		
		JButton btnNewButton_3 = new JButton("More");
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnNewButton_3.setBounds(396, 183, 66, 21);
		frame.getContentPane().add(btnNewButton_3);
		
		JLabel lblNewLabel_6 = new JLabel("");
		lblNewLabel_6.setIcon(new ImageIcon("C:\\Users\\reddy\\Downloads\\es.jpg"));
		lblNewLabel_6.setBounds(513, 110, 140, 94);
		frame.getContentPane().add(lblNewLabel_6);
		
		JLabel lblNewLabel_7 = new JLabel("Ramagiri fort");
		lblNewLabel_7.setBounds(53, 269, 87, 13);
		frame.getContentPane().add(lblNewLabel_7);
		
		JLabel lblNewLabel_8 = new JLabel("Rating:4.4/5");
		lblNewLabel_8.setBounds(53, 292, 73, 13);
		frame.getContentPane().add(lblNewLabel_8);
		
		JButton btnNewButton_4 = new JButton("Call");
		btnNewButton_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e){
			}
		});
		btnNewButton_4.setBounds(53, 315, 66, 21);
		frame.getContentPane().add(btnNewButton_4);
		
		JButton btnNewButton_5 = new JButton("More");
		btnNewButton_5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnNewButton_5.setBounds(53, 346, 66, 21);
		frame.getContentPane().add(btnNewButton_5);
		
		JLabel lblNewLabel_9 = new JLabel("YagnaVaraha Swamy");
		lblNewLabel_9.setBounds(384, 269, 119, 13);
		frame.getContentPane().add(lblNewLabel_9);
		
		JLabel lblNewLabel_10 = new JLabel("Rating:4.6/5");
		lblNewLabel_10.setBounds(396, 292, 66, 13);
		frame.getContentPane().add(lblNewLabel_10);
		
		JButton btnNewButton_2_1 = new JButton("Call");
		btnNewButton_2_1.setBounds(396, 315, 66, 21);
		frame.getContentPane().add(btnNewButton_2_1);
		
		JButton btnNewButton_3_1 = new JButton("More");
		btnNewButton_3_1.setBounds(396, 346, 66, 21);
		frame.getContentPane().add(btnNewButton_3_1);
		
		JLabel lblNewLabel_11 = new JLabel("");
		lblNewLabel_11.setIcon(new ImageIcon("C:\\Users\\reddy\\Downloads\\rs1.jpg"));
		lblNewLabel_11.setBounds(153, 269, 140, 94);
		frame.getContentPane().add(lblNewLabel_11);
		
		JLabel lblNewLabel_12 = new JLabel("");
		lblNewLabel_12.setIcon(new ImageIcon("C:\\Users\\reddy\\Downloads\\y3.jpg"));
		lblNewLabel_12.setBounds(513, 269, 93, 112);
		frame.getContentPane().add(lblNewLabel_12);
		
		JButton btnNewButton_6 = new JButton("Back");
		btnNewButton_6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new Interface2();
				frame.setVisible(false);
			}
		});
		btnNewButton_6.setBounds(53, 419, 79, 21);
		frame.getContentPane().add(btnNewButton_6);
		frame.setVisible(true);	
		
		btnNewButton_1.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent e){
            		new k1();
    				frame.setVisible(false);
            }
        });
		
		btnNewButton_3.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent e){
            		new k11();
    				frame.setVisible(false);
            }
        });
		btnNewButton_5.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent e){
            		new k3();
    				frame.setVisible(false);
            }
        });
		btnNewButton_3_1.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent e){
            		new k4();
    				frame.setVisible(false);
            }
        });
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JOptionPane.showMessageDialog(null,"9990012318");
			}
		});
		
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JOptionPane.showMessageDialog(null,"9001002345");
			}
		});
		btnNewButton_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JOptionPane.showMessageDialog(null,"8542390919");
			}
		});
		btnNewButton_2_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JOptionPane.showMessageDialog(null,"9653224771");
			}
		});
		
	}
}
