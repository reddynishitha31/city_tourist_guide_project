package city;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.BorderLayout;
import java.awt.Color;
import javax.swing.JButton;
import javax.swing.JTextField;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JComboBox;

public class Interface2 {

	private JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Interface2 window = new Interface2();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Interface2() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setTitle("Select Place");
		frame.setIconImage(Toolkit.getDefaultToolkit().getImage("C:\\Users\\reddy\\Pictures\\Screenshots\\sru.png"));
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("State");
		lblNewLabel.setBounds(103, 55, 65, 13);
		lblNewLabel.setForeground(Color.BLACK);
		frame.getContentPane().add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel(" City");
		lblNewLabel_1.setBounds(103, 89, 45, 13);
		frame.getContentPane().add(lblNewLabel_1);
		
		JButton btnNewButton = new JButton("Done");
		btnNewButton.setBounds(314, 201, 85, 21);
		frame.getContentPane().add(btnNewButton);
		
		JLabel lblNewLabel_2 = new JLabel("TELANGANA");
		lblNewLabel_2.setBounds(193, 55, 96, 13);
		frame.getContentPane().add(lblNewLabel_2);
		
		JButton btnNewButton_1 = new JButton("Back");
		btnNewButton_1.setBounds(29, 201, 85, 21);
		frame.getContentPane().add(btnNewButton_1);
		
		JComboBox<String> comboBox = new JComboBox<>(new String[] {"Warangal","Karimnagar","Hyderabad"});
		comboBox.setBounds(193, 85, 85, 21);
		frame.getContentPane().add(comboBox);
		frame.setVisible(true);
		btnNewButton.addActionListener(new ActionListener(){

            public void actionPerformed(ActionEvent e){
            	
                String selectedOption =(String) comboBox.getSelectedItem();
                if(selectedOption.equals("Warangal")) {
                	if(e.getSource()==btnNewButton) {
                	new PlacesVisit();
    				frame.setVisible(false);
                }
                }
                
              
           }
           });
		btnNewButton.addActionListener(new ActionListener(){

            public void actionPerformed(ActionEvent e){
            	
                String selectedOption =(String) comboBox.getSelectedItem();
                if(selectedOption.equals("Karimnagar")) {
                	if(e.getSource()==btnNewButton) {
                	new k();
    				frame.setVisible(false);
                }
                }
                
              
           }
           });
		
		btnNewButton.addActionListener(new ActionListener(){

            public void actionPerformed(ActionEvent e){
            	
                String selectedOption =(String) comboBox.getSelectedItem();
                if(selectedOption.equals("Hyderabad")) {
                	if(e.getSource()==btnNewButton) {
                	new h();
    				frame.setVisible(false);
                }
                }
                
              
           }
           });
		btnNewButton_1.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent e){
            		new user();
    				frame.setVisible(false);
            }
        });
		
        
	}
}
