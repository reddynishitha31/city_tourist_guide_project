package city;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.ImageIcon;

public class k11 {

	private JFrame frame;
	private JTextField textField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					k11 window = new k11();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public k11() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 709, 520);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblNewLabel_1_1 = new JLabel("Elgandal Fort");
		lblNewLabel_1_1.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_1_1.setBounds(294, 21, 134, 15);
		frame.getContentPane().add(lblNewLabel_1_1);
		
		JLabel lblElgandalFortIs = new JLabel("Elgandal Fort is situated amidst palm groves on the banks of the Manair River, approximately 10 kilometres on the ");
		lblElgandalFortIs.setBounds(20, 84, 665, 19);
		frame.getContentPane().add(lblElgandalFortIs);
		
		JLabel lblSircillaRoad = new JLabel("Sircilla Road. It was once under the control of the Qutub Shahi dynasty, the Mughal Empire, and the Nizams of");
		lblSircillaRoad.setBounds(20, 113, 604, 13);
		frame.getContentPane().add(lblSircillaRoad);
		
		JLabel lblNewLabel_6 = new JLabel(" Hyderabad. ");
		lblNewLabel_6.setBounds(20, 136, 312, 19);
		frame.getContentPane().add(lblNewLabel_6);
		
		JLabel lblNewLabel_3_1_1 = new JLabel("Location:");
		lblNewLabel_3_1_1.setBounds(112, 185, 68, 13);
		frame.getContentPane().add(lblNewLabel_3_1_1);
		
		JLabel lblNewLabel_4_1 = new JLabel("Crowd:");
		lblNewLabel_4_1.setBounds(112, 208, 45, 13);
		frame.getContentPane().add(lblNewLabel_4_1);
		
		JLabel lblNewLabel_5_1 = new JLabel("Rating:");
		lblNewLabel_5_1.setBounds(112, 236, 45, 13);
		frame.getContentPane().add(lblNewLabel_5_1);
		
		JLabel lblNewLabel_9_2_1 = new JLabel("Karimnagar");
		lblNewLabel_9_2_1.setBounds(238, 185, 94, 13);
		frame.getContentPane().add(lblNewLabel_9_2_1);
		
		JLabel lblNewLabel_4_2 = new JLabel("low");
		lblNewLabel_4_2.setBounds(238, 208, 45, 13);
		frame.getContentPane().add(lblNewLabel_4_2);
		
		JLabel lblNewLabel_9 = new JLabel("4.6/5");
		lblNewLabel_9.setBounds(238, 236, 45, 13);
		frame.getContentPane().add(lblNewLabel_9);
		
		JLabel lblNewLabel_8_1 = new JLabel("FeedBack");
		lblNewLabel_8_1.setBounds(112, 272, 85, 13);
		frame.getContentPane().add(lblNewLabel_8_1);
		
		textField = new JTextField();
		textField.setColumns(10);
		textField.setBounds(231, 269, 75, 41);
		frame.getContentPane().add(textField);
		
		JButton btnNewButton_2 = new JButton("Submit");
		btnNewButton_2.setFont(new Font("Tahoma", Font.PLAIN, 9));
		btnNewButton_2.setBounds(238, 320, 68, 21);
		frame.getContentPane().add(btnNewButton_2);
		
		JButton btnNewButton_1 = new JButton("Back");
		btnNewButton_1.setBounds(38, 367, 75, 21);
		frame.getContentPane().add(btnNewButton_1);
		
		JLabel lblNewLabel_10_1 = new JLabel("");
		lblNewLabel_10_1.setIcon(new ImageIcon("C:\\Users\\reddy\\Downloads\\es.jpg"));
		lblNewLabel_10_1.setBounds(430, 186, 150, 99);
		frame.getContentPane().add(lblNewLabel_10_1);
		
		
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JOptionPane.showMessageDialog(null,"Feedback Success");
			}
		});
		
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frame.getContentPane().setVisible(false);
				frame.dispose();
				k.main(null);
			}
		});
		frame.setVisible(true);	
	}

}
