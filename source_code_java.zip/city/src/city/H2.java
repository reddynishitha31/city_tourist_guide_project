package city;

import java.awt.EventQueue;

import javax.swing.JFrame;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.ImageIcon;

public class H2 {

	private JFrame frame;
	private JTextField textField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					H2 window = new H2();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public H2() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setIconImage(Toolkit.getDefaultToolkit().getImage("C:\\Users\\reddy\\Pictures\\Screenshots\\sru.png"));
		frame.setBounds(100, 100, 594, 422);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblGolcondaFort = new JLabel("Golconda Fort");
		lblGolcondaFort.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblGolcondaFort.setBounds(223, 26, 113, 15);
		frame.getContentPane().add(lblGolcondaFort);
		
		JLabel lblGolcondaIsA = new JLabel("Golconda is a historic fortress and ruined city located in the western outskirts of Hyderabad. The ");
		lblGolcondaIsA.setBounds(10, 60, 558, 13);
		frame.getContentPane().add(lblGolcondaIsA);
		
		JLabel lblBuiltByKakatiya = new JLabel("fort was originally built by Kakatiya ruler Prat\u0101parudra in the 11th century out of mud walls. The ");
		lblBuiltByKakatiya.setBounds(10, 85, 558, 13);
		frame.getContentPane().add(lblBuiltByKakatiya);
		
		JLabel lblAVaultWhere = new JLabel(" Golconda fort used to have a vault where the famous Koh-i-Noor and Hope diamonds.");
		lblAVaultWhere.setBounds(10, 108, 558, 13);
		frame.getContentPane().add(lblAVaultWhere);
		
		JLabel lblNewLabel_3_1_1 = new JLabel("Location:");
		lblNewLabel_3_1_1.setBounds(115, 141, 68, 13);
		frame.getContentPane().add(lblNewLabel_3_1_1);
		
		JLabel lblNewLabel_4_1 = new JLabel("Crowd:");
		lblNewLabel_4_1.setBounds(115, 164, 45, 13);
		frame.getContentPane().add(lblNewLabel_4_1);
		
		JLabel lblNewLabel_5_1 = new JLabel("Rating:");
		lblNewLabel_5_1.setBounds(115, 187, 45, 20);
		frame.getContentPane().add(lblNewLabel_5_1);
		
		JLabel lblNewLabel_9_2_1 = new JLabel("Hyderadab");
		lblNewLabel_9_2_1.setBounds(244, 141, 67, 21);
		frame.getContentPane().add(lblNewLabel_9_2_1);
		
		JLabel lblNewLabel_9_2_1_1 = new JLabel("average");
		lblNewLabel_9_2_1_1.setBounds(244, 164, 67, 21);
		frame.getContentPane().add(lblNewLabel_9_2_1_1);
		
		JLabel lblNewLabel_9_2_1_2 = new JLabel("4.4/5");
		lblNewLabel_9_2_1_2.setBounds(244, 191, 67, 21);
		frame.getContentPane().add(lblNewLabel_9_2_1_2);
		
		JLabel lblNewLabel_9_2_1_3 = new JLabel("Feedback:");
		lblNewLabel_9_2_1_3.setBounds(116, 217, 67, 21);
		frame.getContentPane().add(lblNewLabel_9_2_1_3);
		
		textField = new JTextField();
		textField.setColumns(10);
		textField.setBounds(236, 218, 75, 41);
		frame.getContentPane().add(textField);
		
		JButton btnNewButton_2 = new JButton("Submit");
		btnNewButton_2.setFont(new Font("Tahoma", Font.PLAIN, 9));
		btnNewButton_2.setBounds(236, 269, 75, 21);
		frame.getContentPane().add(btnNewButton_2);
		
		JButton btnNewButton_1_1 = new JButton("Back");
		btnNewButton_1_1.setBounds(47, 323, 75, 21);
		frame.getContentPane().add(btnNewButton_1_1);
		
		JLabel lblNewLabel_10_1 = new JLabel("");
		lblNewLabel_10_1.setIcon(new ImageIcon("C:\\Users\\reddy\\Pictures\\Saved Pictures\\g1.jpg"));
		lblNewLabel_10_1.setBounds(381, 141, 150, 102);
		frame.getContentPane().add(lblNewLabel_10_1);
		frame.setVisible(true);
		
		btnNewButton_1_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frame.getContentPane().setVisible(false);
				frame.dispose();
				h.main(null);
			}
		});

		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JOptionPane.showMessageDialog(null,"Feedback Success");
			}
		});
		
	}

}
