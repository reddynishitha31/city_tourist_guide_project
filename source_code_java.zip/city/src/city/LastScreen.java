package city;

import java.awt.EventQueue;

import javax.swing.JFrame;
import java.awt.Toolkit;
import javax.swing.JButton;
import java.awt.BorderLayout;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.ImageIcon;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class LastScreen {

	private JFrame frame;
	private JTextField textField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					LastScreen window = new LastScreen();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public LastScreen() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setTitle("Thousand Pillar Temple");
		frame.setIconImage(Toolkit.getDefaultToolkit().getImage("C:\\Users\\reddy\\Pictures\\Screenshots\\sru.png"));
		frame.setBounds(100, 100, 523, 380);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JButton btnNewButton = new JButton("back");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frame.getContentPane().setVisible(false);
				frame.dispose();
				PlacesVisit.main(null);
			}
		});
		btnNewButton.setBounds(21, 301, 66, 21);
		frame.getContentPane().add(btnNewButton);
		
		JLabel lblNewLabel = new JLabel("Thounsand Pillar Temple");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel.setBounds(161, 10, 190, 34);
		frame.getContentPane().add(lblNewLabel);
		
		JLabel lblNewLabel_7 = new JLabel("At this temple, three deities- Lord Shiva, Lord Vishnu and Lord Surya are worshipped.");
		lblNewLabel_7.setBounds(10, 47, 484, 20);
		frame.getContentPane().add(lblNewLabel_7);
		
		JLabel lblNewLabel_8 = new JLabel("This temple is a fine specimen of architecture and sculpture with One thousand pillars.");
		lblNewLabel_8.setBounds(10, 77, 489, 16);
		frame.getContentPane().add(lblNewLabel_8);
		
		JLabel lblNewLabel_1 = new JLabel("location :");
		lblNewLabel_1.setBounds(142, 103, 53, 20);
		frame.getContentPane().add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Hanmakonda");
		lblNewLabel_2.setBounds(228, 107, 85, 16);
		frame.getContentPane().add(lblNewLabel_2);
		
		JLabel lblNewLabel_5 = new JLabel("Crowd :");
		lblNewLabel_5.setBounds(142, 133, 45, 13);
		frame.getContentPane().add(lblNewLabel_5);
		
		JLabel lblNewLabel_6 = new JLabel("Average");
		lblNewLabel_6.setBounds(228, 133, 71, 13);
		frame.getContentPane().add(lblNewLabel_6);
		
		JLabel lblNewLabel_3 = new JLabel("Rating:");
		lblNewLabel_3.setBounds(142, 158, 45, 16);
		frame.getContentPane().add(lblNewLabel_3);
		
		JLabel lblNewLabel_4 = new JLabel("Feedback:");
		lblNewLabel_4.setBounds(124, 205, 71, 16);
		frame.getContentPane().add(lblNewLabel_4);
		
		textField = new JTextField();
		textField.setColumns(10);
		textField.setBounds(205, 204, 94, 34);
		frame.getContentPane().add(textField);
		
		JButton submitButton = new JButton("Submit");
		submitButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JOptionPane.showMessageDialog(null,"Feedback Success");
			}
		});
		submitButton.setBounds(215, 245, 71, 21);
		frame.getContentPane().add(submitButton);
		
		JLabel lblNewLabel_9 = new JLabel("4.4/5");
		lblNewLabel_9.setBounds(228, 160, 45, 13);
		frame.getContentPane().add(lblNewLabel_9);
		
		JLabel lblNewLabel_10 = new JLabel("");
		lblNewLabel_10.setIcon(new ImageIcon("C:\\Users\\reddy\\Downloads\\1000pillartemple.jpg"));
		lblNewLabel_10.setBounds(357, 133, 126, 76);
		frame.getContentPane().add(lblNewLabel_10);
		frame.setVisible(true);
	}
}
