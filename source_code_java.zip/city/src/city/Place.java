package city;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JButton;
import java.awt.BorderLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Place {

	private JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Place window = new Place();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Place() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setTitle("Places To Be Visited");
		frame.setIconImage(Toolkit.getDefaultToolkit().getImage("C:\\Users\\reddy\\Pictures\\Screenshots\\sru.png"));
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);		
		JButton btnNewButton = new JButton("Places To Be Visited");
		btnNewButton.setBounds(21, 47, 171, 21);
		frame.getContentPane().add(btnNewButton);		
		frame.setVisible(true);		
		btnNewButton.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent e){            	              
            		new PlacesVisit();
    				frame.setVisible(false);
            }
        });
	}
}
