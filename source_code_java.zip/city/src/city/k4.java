package city;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.ImageIcon;

public class k4 {

	private JFrame frame;
	private JTextField textField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					k4 window = new k4();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public k4() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setIconImage(Toolkit.getDefaultToolkit().getImage("C:\\Users\\reddy\\Pictures\\Screenshots\\sru.png"));
		frame.setBounds(100, 100, 663, 489);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblNewLabel_1_1 = new JLabel("YagnaVaraha Swamy");
		lblNewLabel_1_1.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_1_1.setBounds(202, 23, 134, 15);
		frame.getContentPane().add(lblNewLabel_1_1);
		
		JLabel lblYagnaVarahaSwamy = new JLabel("Yagna Varaha Swamy temple, the presiding deity as an incarnation of Lord Vishnu in the form of a wild boar, is ");
		lblYagnaVarahaSwamy.setBounds(10, 65, 629, 13);
		frame.getContentPane().add(lblYagnaVarahaSwamy);
		
		JLabel lblDevoteesIn = new JLabel("worshipped by devotees in large numbers in this tiny village of Kamanpur Mandal in Karimnagar district.");
		lblDevoteesIn.setBounds(10, 88, 597, 13);
		frame.getContentPane().add(lblDevoteesIn);
		
		JLabel lblThisTempleIs = new JLabel("This temple is built as per traditional Dravidian Architecture.");
		lblThisTempleIs.setBounds(10, 111, 534, 13);
		frame.getContentPane().add(lblThisTempleIs);
		
		JLabel lblNewLabel_3_1_1 = new JLabel("Location:");
		lblNewLabel_3_1_1.setBounds(104, 149, 68, 13);
		frame.getContentPane().add(lblNewLabel_3_1_1);
		
		JLabel lblNewLabel_4_1 = new JLabel("Crowd:");
		lblNewLabel_4_1.setBounds(104, 172, 45, 13);
		frame.getContentPane().add(lblNewLabel_4_1);
		
		JLabel lblNewLabel_5_1 = new JLabel("Rating:");
		lblNewLabel_5_1.setBounds(104, 195, 45, 13);
		frame.getContentPane().add(lblNewLabel_5_1);
		
		JLabel lblNewLabel_9_2_1 = new JLabel("Karimnagar");
		lblNewLabel_9_2_1.setBounds(245, 149, 75, 13);
		frame.getContentPane().add(lblNewLabel_9_2_1);
		
		JLabel lblNewLabel_9_2_1_1 = new JLabel("average");
		lblNewLabel_9_2_1_1.setBounds(245, 172, 58, 13);
		frame.getContentPane().add(lblNewLabel_9_2_1_1);
		
		JLabel lblNewLabel_9_3 = new JLabel("4.6/5");
		lblNewLabel_9_3.setBounds(245, 195, 45, 13);
		frame.getContentPane().add(lblNewLabel_9_3);
		
		JLabel lblNewLabel_8_1 = new JLabel("FeedBack");
		lblNewLabel_8_1.setBounds(104, 226, 85, 13);
		frame.getContentPane().add(lblNewLabel_8_1);
		
		textField = new JTextField();
		textField.setColumns(10);
		textField.setBounds(228, 226, 75, 41);
		frame.getContentPane().add(textField);
		
		JButton btnNewButton_2 = new JButton("Submit");
		btnNewButton_2.setBounds(228, 277, 75, 21);
		frame.getContentPane().add(btnNewButton_2);
		
		JButton btnNewButton_1_1 = new JButton("Back");
		btnNewButton_1_1.setBounds(61, 331, 75, 21);
		frame.getContentPane().add(btnNewButton_1_1);
		
		JLabel lblNewLabel_10_1 = new JLabel("");
		lblNewLabel_10_1.setIcon(new ImageIcon("C:\\Users\\reddy\\Downloads\\y3.jpg"));
		lblNewLabel_10_1.setBounds(401, 149, 90, 99);
		frame.getContentPane().add(lblNewLabel_10_1);
		
		frame.setVisible(true);	

		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JOptionPane.showMessageDialog(null,"Feedback Success");
			}
		});
		
		btnNewButton_1_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frame.getContentPane().setVisible(false);
				frame.dispose();
				k.main(null);
			}
		});
	}

}
