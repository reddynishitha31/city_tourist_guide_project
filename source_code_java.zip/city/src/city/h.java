package city;

import java.awt.EventQueue;

import javax.swing.JFrame;
import java.awt.Toolkit;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.ImageIcon;

public class h {

	private JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					h window = new h();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public h() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setIconImage(Toolkit.getDefaultToolkit().getImage("C:\\Users\\reddy\\Pictures\\Screenshots\\sru.png"));
		frame.setBounds(100, 100, 646, 476);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblHyderbad = new JLabel("Hyderabad");
		lblHyderbad.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblHyderbad.setBounds(270, 20, 79, 39);
		frame.getContentPane().add(lblHyderbad);
		
		JLabel lblNewLabel_4 = new JLabel("Charminar");
		lblNewLabel_4.setBounds(69, 84, 107, 13);
		frame.getContentPane().add(lblNewLabel_4);
		
		JLabel lblNewLabel_4_1 = new JLabel("Golconda Fort");
		lblNewLabel_4_1.setBounds(356, 84, 107, 13);
		frame.getContentPane().add(lblNewLabel_4_1);
		
		JLabel lblNewLabel_2 = new JLabel("Rating:4.5/5");
		lblNewLabel_2.setBounds(69, 107, 73, 13);
		frame.getContentPane().add(lblNewLabel_2);
		
		JLabel lblNewLabel_2_1 = new JLabel("Rating:4.4/5");
		lblNewLabel_2_1.setBounds(356, 107, 73, 13);
		frame.getContentPane().add(lblNewLabel_2_1);
		
		JLabel lblNewLabel_2_2 = new JLabel("Rating:4.7/5");
		lblNewLabel_2_2.setBounds(69, 275, 73, 13);
		frame.getContentPane().add(lblNewLabel_2_2);
		
		JLabel lblNewLabel_2_3 = new JLabel("Rating:4.4/5");
		lblNewLabel_2_3.setBounds(356, 275, 73, 13);
		frame.getContentPane().add(lblNewLabel_2_3);
		
		JLabel lblNewLabel_4_2 = new JLabel("Birla Mandir");
		lblNewLabel_4_2.setBounds(69, 252, 107, 13);
		frame.getContentPane().add(lblNewLabel_4_2);
		
		JLabel lblNewLabel_4_3 = new JLabel("Ramoji Film City");
		lblNewLabel_4_3.setBounds(356, 252, 107, 13);
		frame.getContentPane().add(lblNewLabel_4_3);
		
		JButton btnNewButton = new JButton("Call");
		btnNewButton.setBounds(69, 130, 66, 21);
		frame.getContentPane().add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("Call");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnNewButton_1.setBounds(356, 130, 66, 21);
		frame.getContentPane().add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("Call");
		btnNewButton_2.setBounds(356, 298, 66, 21);
		frame.getContentPane().add(btnNewButton_2);
		
		JButton btnNewButton_3 = new JButton("Call");
		btnNewButton_3.setBounds(69, 298, 66, 21);
		frame.getContentPane().add(btnNewButton_3);
		
		JButton btnNewButton_1_1 = new JButton("More");
		btnNewButton_1_1.setBounds(69, 161, 66, 21);
		frame.getContentPane().add(btnNewButton_1_1);
		
		JButton btnNewButton_1_2 = new JButton("More");
		btnNewButton_1_2.setBounds(356, 161, 66, 21);
		frame.getContentPane().add(btnNewButton_1_2);
		
		JButton btnNewButton_1_3 = new JButton("More");
		btnNewButton_1_3.setBounds(69, 329, 66, 21);
		frame.getContentPane().add(btnNewButton_1_3);
		
		JButton btnNewButton_1_4 = new JButton("More");
		btnNewButton_1_4.setBounds(356, 329, 66, 21);
		frame.getContentPane().add(btnNewButton_1_4);
		
		JButton btnNewButton_6 = new JButton("Back");
		btnNewButton_6.setBounds(24, 389, 79, 21);
		frame.getContentPane().add(btnNewButton_6);
		
		JLabel lblNewLabel_3 = new JLabel("");
		lblNewLabel_3.setIcon(new ImageIcon("C:\\Users\\reddy\\Pictures\\Saved Pictures\\c1.jpg"));
		lblNewLabel_3.setBounds(162, 107, 140, 100);
		frame.getContentPane().add(lblNewLabel_3);
		
		JLabel lblNewLabel_3_1 = new JLabel("");
		lblNewLabel_3_1.setIcon(new ImageIcon("C:\\Users\\reddy\\Pictures\\Saved Pictures\\g1.jpg"));
		lblNewLabel_3_1.setBounds(451, 95, 140, 100);
		frame.getContentPane().add(lblNewLabel_3_1);
		
		JLabel lblNewLabel_3_2 = new JLabel("");
		lblNewLabel_3_2.setIcon(new ImageIcon("C:\\Users\\reddy\\Pictures\\Saved Pictures\\b1.jpg"));
		lblNewLabel_3_2.setBounds(162, 275, 140, 100);
		frame.getContentPane().add(lblNewLabel_3_2);
		
		JLabel lblNewLabel_3_3 = new JLabel("");
		lblNewLabel_3_3.setIcon(new ImageIcon("C:\\Users\\reddy\\Pictures\\Saved Pictures\\r1.jpg"));
		lblNewLabel_3_3.setBounds(451, 275, 140, 100);
		frame.getContentPane().add(lblNewLabel_3_3);
		
		
		btnNewButton_1_1.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent e){
            		new h1();
    				frame.setVisible(false);
            }
        });
		
		btnNewButton_1_2.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent e){
            		new H2();
    				frame.setVisible(false);
            }
        });
		btnNewButton_1_3.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent e){
            		new H3();
    				frame.setVisible(false);
            }
        });
		btnNewButton_1_4.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent e){
            		new H4();
    				frame.setVisible(false);
            }
        });
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JOptionPane.showMessageDialog(null,"9980012318");
			}
		});
		
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JOptionPane.showMessageDialog(null,"9001005345");
			}
		});
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JOptionPane.showMessageDialog(null,"8542310919");
			}
		});
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JOptionPane.showMessageDialog(null,"9653224661");
			}
		});
		frame.setVisible(true);	
		btnNewButton_6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new Interface2();
				frame.setVisible(false);
			}
		});
	}
	
}
