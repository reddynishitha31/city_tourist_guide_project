package city;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;

public class k1 {

	private JFrame frame;
	private JTextField textField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					k1 window = new k1();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public k1() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setIconImage(Toolkit.getDefaultToolkit().getImage("C:\\Users\\reddy\\Pictures\\Screenshots\\sru.png"));
		frame.setBounds(100, 100, 678, 437);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("The Lower Manair Dam is located on the Manair River at 18\u00B024' N latitude and 79\u00B0 20' E longitude in Karimnagar District ");
		lblNewLabel.setBounds(42, 81, 558, 13);
		frame.getContentPane().add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Lower Manair Dam");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_1.setBounds(259, 37, 131, 20);
		frame.getContentPane().add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("at 146 of Kakatiya Canal. The dam drains a catchment area of 6,464 square kilometres which includes 1,797.46 ");
		lblNewLabel_2.setBounds(52, 109, 558, 13);
		frame.getContentPane().add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("square kilometres of free catchment.");
		lblNewLabel_3.setBounds(62, 132, 288, 13);
		frame.getContentPane().add(lblNewLabel_3);
		
		JLabel lblNewLabel_3_1 = new JLabel("Location:");
		lblNewLabel_3_1.setBounds(123, 177, 68, 13);
		frame.getContentPane().add(lblNewLabel_3_1);
		
		JLabel lblNewLabel_4 = new JLabel("Crowd:");
		lblNewLabel_4.setBounds(123, 200, 45, 13);
		frame.getContentPane().add(lblNewLabel_4);
		
		JLabel lblNewLabel_5 = new JLabel("Rating:");
		lblNewLabel_5.setBounds(123, 223, 45, 13);
		frame.getContentPane().add(lblNewLabel_5);
		
		JLabel lblNewLabel_9 = new JLabel("4.6/5");
		lblNewLabel_9.setBounds(292, 223, 45, 13);
		frame.getContentPane().add(lblNewLabel_9);
		
		JLabel lblNewLabel_9_1 = new JLabel("average");
		lblNewLabel_9_1.setBounds(292, 200, 124, 13);
		frame.getContentPane().add(lblNewLabel_9_1);
		
		JLabel lblNewLabel_9_2 = new JLabel("Karimnagar");
		lblNewLabel_9_2.setBounds(292, 177, 98, 20);
		frame.getContentPane().add(lblNewLabel_9_2);
		
		JLabel lblNewLabel_8 = new JLabel("FeedBack");
		lblNewLabel_8.setBounds(123, 276, 85, 13);
		frame.getContentPane().add(lblNewLabel_8);
		
		textField = new JTextField();
		textField.setColumns(10);
		textField.setBounds(285, 273, 75, 41);
		frame.getContentPane().add(textField);
		
		JButton btnNewButton = new JButton("Submit");
		btnNewButton.setBounds(285, 324, 75, 21);
		frame.getContentPane().add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("Back");
		btnNewButton_1.setBounds(31, 352, 75, 21);
		frame.getContentPane().add(btnNewButton_1);
		
		JLabel lblNewLabel_10 = new JLabel("");
		lblNewLabel_10.setIcon(new ImageIcon("C:\\Users\\reddy\\Downloads\\ls.jpg"));
		lblNewLabel_10.setBounds(455, 177, 150, 90);
		frame.getContentPane().add(lblNewLabel_10);
		
		frame.setVisible(true);	
		
		btnNewButton .addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JOptionPane.showMessageDialog(null,"Feedback Success");
			}
		});
		
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frame.getContentPane().setVisible(false);
				frame.dispose();
				k.main(null);
			}
		});
	}
}
