package city;

import java.awt.EventQueue;

import javax.swing.JFrame;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.ImageIcon;

public class k3 {

	private JFrame frame;
	private JTextField textField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					k3 window = new k3();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public k3() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setIconImage(Toolkit.getDefaultToolkit().getImage("C:\\Users\\reddy\\Pictures\\Screenshots\\sru.png"));
		frame.setBounds(100, 100, 695, 466);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblNewLabel_1_1 = new JLabel("Ramagiri fort");
		lblNewLabel_1_1.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_1_1.setBounds(198, 22, 134, 15);
		frame.getContentPane().add(lblNewLabel_1_1);
		
		JLabel lblTheRamagiriFort = new JLabel("The Ramagiri Fort, also known as Ramagiri Khilla, located over a mountain top, is in the Peddapalli district of the");
		lblTheRamagiriFort.setBounds(10, 60, 661, 13);
		frame.getContentPane().add(lblTheRamagiriFort);
		
		JLabel lblIndianStateOf = new JLabel(" Indian state of Telangana. The fort, located on the Ramagiri hills, is near the Begumpet village in ");
		lblIndianStateOf.setBounds(10, 83, 621, 13);
		frame.getContentPane().add(lblIndianStateOf);
		
		JLabel lblRamagiriMandalIn = new JLabel("Ramagiri mandal in Peddapalli district.");
		lblRamagiriMandalIn.setBounds(10, 106, 558, 13);
		frame.getContentPane().add(lblRamagiriMandalIn);
		
		JLabel lblNewLabel_3_1_1 = new JLabel("Location:");
		lblNewLabel_3_1_1.setBounds(114, 148, 68, 13);
		frame.getContentPane().add(lblNewLabel_3_1_1);
		
		JLabel lblNewLabel_4_1 = new JLabel("Crowd:");
		lblNewLabel_4_1.setBounds(114, 171, 45, 13);
		frame.getContentPane().add(lblNewLabel_4_1);
		
		JLabel lblNewLabel_5_1 = new JLabel("Rating:");
		lblNewLabel_5_1.setBounds(114, 186, 45, 28);
		frame.getContentPane().add(lblNewLabel_5_1);
		
		JLabel lblNewLabel_4_2 = new JLabel("low");
		lblNewLabel_4_2.setBounds(265, 171, 45, 13);
		frame.getContentPane().add(lblNewLabel_4_2);
		
		JLabel lblNewLabel_9_3 = new JLabel("4.4/5");
		lblNewLabel_9_3.setBounds(265, 194, 45, 13);
		frame.getContentPane().add(lblNewLabel_9_3);
		
		JLabel lblNewLabel_8_1 = new JLabel("FeedBack");
		lblNewLabel_8_1.setBounds(114, 248, 85, 13);
		frame.getContentPane().add(lblNewLabel_8_1);
		
		textField = new JTextField();
		textField.setColumns(10);
		textField.setBounds(248, 245, 75, 41);
		frame.getContentPane().add(textField);
		
		JButton btnNewButton_2 = new JButton("Submit");
		btnNewButton_2.setFont(new Font("Tahoma", Font.PLAIN, 9));
		btnNewButton_2.setBounds(247, 293, 75, 21);
		frame.getContentPane().add(btnNewButton_2);
		
		JButton btnNewButton_1_1 = new JButton("Back");
		btnNewButton_1_1.setBounds(45, 347, 75, 21);
		frame.getContentPane().add(btnNewButton_1_1);
		
		JLabel lblNewLabel_10_1 = new JLabel("");
		lblNewLabel_10_1.setIcon(new ImageIcon("C:\\Users\\reddy\\Downloads\\rs1.jpg"));
		lblNewLabel_10_1.setBounds(370, 148, 150, 99);
		frame.getContentPane().add(lblNewLabel_10_1);
		
		JLabel lblNewLabel_9_2_1 = new JLabel("Karimnagar");
		lblNewLabel_9_2_1.setBounds(265, 148, 67, 21);
		frame.getContentPane().add(lblNewLabel_9_2_1);
		frame.setVisible(true);	
		

		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JOptionPane.showMessageDialog(null,"Feedback Success");
			}
		});
		
		btnNewButton_1_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frame.getContentPane().setVisible(false);
				frame.dispose();
				k.main(null);
			}
		});
	}

}
