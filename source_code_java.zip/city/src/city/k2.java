package city;

import java.awt.EventQueue;

import javax.swing.JFrame;
import java.awt.BorderLayout;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.ImageIcon;
import java.awt.Toolkit;

public class k2 {

	private JFrame frame;
	private JTextField textField;
	private JTextField textField_1;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					k2 window = new k2();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public k2() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setIconImage(Toolkit.getDefaultToolkit().getImage("C:\\Users\\reddy\\Pictures\\Screenshots\\sru.png"));
		frame.setBounds(100, 100, 602, 446);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JFrame frame_1 = new JFrame();
		frame_1.setBounds(-10007, -10030, 0, 0);
		frame_1.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("The Lower Manair Dam is located on the Manair River at 18\u00B024' N latitude and 79\u00B0 20' E longitude in Karimnagar District ");
		lblNewLabel.setBounds(42, 81, 558, 13);
		frame_1.getContentPane().add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Lower Manair Dam");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_1.setBounds(259, 37, 131, 20);
		frame_1.getContentPane().add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("at 146 of Kakatiya Canal. The dam drains a catchment area of 6,464 square kilometres which includes 1,797.46 ");
		lblNewLabel_2.setBounds(52, 109, 558, 13);
		frame_1.getContentPane().add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("square kilometres of free catchment.");
		lblNewLabel_3.setBounds(62, 132, 288, 13);
		frame_1.getContentPane().add(lblNewLabel_3);
		
		JLabel lblNewLabel_3_1 = new JLabel("Location:");
		lblNewLabel_3_1.setBounds(123, 177, 68, 13);
		frame_1.getContentPane().add(lblNewLabel_3_1);
		
		JLabel lblNewLabel_4 = new JLabel("Crowd:");
		lblNewLabel_4.setBounds(123, 211, 45, 13);
		frame_1.getContentPane().add(lblNewLabel_4);
		
		JLabel lblNewLabel_5 = new JLabel("Rating:");
		lblNewLabel_5.setBounds(123, 234, 45, 13);
		frame_1.getContentPane().add(lblNewLabel_5);
		
		JLabel lblNewLabel_9 = new JLabel("4.6/5");
		lblNewLabel_9.setBounds(292, 234, 45, 13);
		frame_1.getContentPane().add(lblNewLabel_9);
		
		JLabel lblNewLabel_9_1 = new JLabel("average");
		lblNewLabel_9_1.setBounds(292, 211, 45, 13);
		frame_1.getContentPane().add(lblNewLabel_9_1);
		
		JLabel lblNewLabel_9_2 = new JLabel("Karimnagar");
		lblNewLabel_9_2.setBounds(292, 177, 58, 13);
		frame_1.getContentPane().add(lblNewLabel_9_2);
		
		JLabel lblNewLabel_8 = new JLabel("FeedBack");
		lblNewLabel_8.setBounds(123, 276, 85, 13);
		frame_1.getContentPane().add(lblNewLabel_8);
		
		textField = new JTextField();
		textField.setColumns(10);
		textField.setBounds(285, 273, 75, 41);
		frame_1.getContentPane().add(textField);
		
		JButton btnNewButton = new JButton("Submit");
		btnNewButton.setBounds(285, 324, 85, 21);
		frame_1.getContentPane().add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("Back");
		btnNewButton_1.setBounds(31, 352, 75, 21);
		frame_1.getContentPane().add(btnNewButton_1);
		
		JLabel lblNewLabel_10 = new JLabel("");
		lblNewLabel_10.setBounds(455, 177, 150, 90);
		frame_1.getContentPane().add(lblNewLabel_10);
		frame_1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().add(frame_1);
		
		JLabel lblNewLabel_1_1 = new JLabel("Elgandal Fort");
		lblNewLabel_1_1.setBounds(211, 20, 134, 15);
		lblNewLabel_1_1.setFont(new Font("Tahoma", Font.BOLD, 12));
		frame.getContentPane().add(lblNewLabel_1_1);
		
		JLabel lblElgandalFortIs = new JLabel("Elgandal Fort is situated amidst palm groves on the banks of the Manair River, approximately 10 kilometres on the ");
		lblElgandalFortIs.setBounds(10, 45, 558, 19);
		frame.getContentPane().add(lblElgandalFortIs);
		
		JLabel lblSircillaRoad = new JLabel("Sircilla Road. It was once under the control of the Qutub Shahi dynasty, the Mughal Empire, and the Nizams of");
		lblSircillaRoad.setBounds(10, 74, 558, 13);
		frame.getContentPane().add(lblSircillaRoad);
		
		JLabel lblNewLabel_6 = new JLabel(" Hyderabad. ");
		lblNewLabel_6.setBounds(10, 97, 312, 19);
		frame.getContentPane().add(lblNewLabel_6);
		
		JLabel lblNewLabel_3_1_1 = new JLabel("Location:");
		lblNewLabel_3_1_1.setBounds(123, 149, 68, 13);
		frame.getContentPane().add(lblNewLabel_3_1_1);
		
		JLabel lblNewLabel_9_2_1 = new JLabel("Karimnagar");
		lblNewLabel_9_2_1.setBounds(275, 149, 58, 13);
		frame.getContentPane().add(lblNewLabel_9_2_1);
		
		JLabel lblNewLabel_4_1 = new JLabel("Crowd:");
		lblNewLabel_4_1.setBounds(123, 172, 45, 13);
		frame.getContentPane().add(lblNewLabel_4_1);
		
		JLabel lblNewLabel_4_2 = new JLabel("low");
		lblNewLabel_4_2.setBounds(275, 172, 45, 13);
		frame.getContentPane().add(lblNewLabel_4_2);
		
		JLabel lblNewLabel_5_1 = new JLabel("Rating:");
		lblNewLabel_5_1.setBounds(123, 195, 45, 13);
		frame.getContentPane().add(lblNewLabel_5_1);
		
		JLabel lblNewLabel_9_3 = new JLabel("4.3/5");
		lblNewLabel_9_3.setBounds(275, 195, 45, 13);
		frame.getContentPane().add(lblNewLabel_9_3);
		
		JLabel lblNewLabel_8_1 = new JLabel("FeedBack");
		lblNewLabel_8_1.setBounds(112, 252, 85, 13);
		frame.getContentPane().add(lblNewLabel_8_1);
		
		textField_1 = new JTextField();
		textField_1.setColumns(10);
		textField_1.setBounds(250, 252, 75, 41);
		frame.getContentPane().add(textField_1);
		
		JButton btnNewButton_2 = new JButton("Submit");
		btnNewButton_2.setBounds(250, 303, 85, 21);
		frame.getContentPane().add(btnNewButton_2);
		
		JButton btnNewButton_1_1 = new JButton("Back");
		btnNewButton_1_1.setBounds(39, 345, 75, 21);
		frame.getContentPane().add(btnNewButton_1_1);
		
		JLabel lblNewLabel_10_1 = new JLabel("");
		lblNewLabel_10_1.setIcon(new ImageIcon("C:\\Users\\reddy\\Downloads\\es.jpg"));
		lblNewLabel_10_1.setBounds(386, 149, 150, 99);
		frame.getContentPane().add(lblNewLabel_10_1);
		
		frame.setVisible(true);	
		
	}

}
