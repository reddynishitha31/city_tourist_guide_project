package city;

import java.awt.EventQueue;

import javax.swing.JFrame;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.BorderLayout;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.ImageIcon;

public class h1 {

	private JFrame frame;
	private JTextField textField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					h1 window = new h1();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public h1() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setIconImage(Toolkit.getDefaultToolkit().getImage("C:\\Users\\reddy\\Pictures\\Screenshots\\sru.png"));
		frame.setBounds(100, 100, 595, 417);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblCharminar = new JLabel("Charminar");
		lblCharminar.setBounds(239, 20, 113, 15);
		lblCharminar.setFont(new Font("Tahoma", Font.BOLD, 12));
		frame.getContentPane().add(lblCharminar);
		
		JLabel lblCharminarIsLocated = new JLabel("Charminar is located in the heart of Hyderabad city in the state of Telangana. This historical ");
		lblCharminarIsLocated.setBounds(10, 45, 558, 13);
		frame.getContentPane().add(lblCharminarIsLocated);
		
		JLabel lblFMusiRiver = new JLabel("monument lies on the east bank of Musi River on Charminar Road. It was built in 1591 by Sultan  ");
		lblFMusiRiver.setBounds(10, 68, 558, 13);
		frame.getContentPane().add(lblFMusiRiver);
		
		JLabel lblRulerOfThe = new JLabel("Muhammad Quli Qutub Shah, the fifth ruler of the Qutb Shahi dynasty.");
		lblRulerOfThe.setBounds(10, 91, 558, 13);
		frame.getContentPane().add(lblRulerOfThe);
		
		JLabel lblNewLabel_3_1_1 = new JLabel("Location:");
		lblNewLabel_3_1_1.setBounds(107, 125, 68, 13);
		frame.getContentPane().add(lblNewLabel_3_1_1);
		
		JLabel lblNewLabel_4_1 = new JLabel("Crowd:");
		lblNewLabel_4_1.setBounds(107, 148, 45, 13);
		frame.getContentPane().add(lblNewLabel_4_1);
		
		JLabel lblNewLabel_5_1 = new JLabel("Rating:");
		lblNewLabel_5_1.setBounds(107, 171, 45, 20);
		frame.getContentPane().add(lblNewLabel_5_1);
		
		JLabel lblNewLabel_9_2_1 = new JLabel("Hyderadab");
		lblNewLabel_9_2_1.setBounds(239, 125, 67, 21);
		frame.getContentPane().add(lblNewLabel_9_2_1);
		
		JLabel lblNewLabel_9_2_1_1 = new JLabel("high");
		lblNewLabel_9_2_1_1.setBounds(239, 148, 67, 21);
		frame.getContentPane().add(lblNewLabel_9_2_1_1);
		
		JLabel lblNewLabel_9_2_1_2 = new JLabel("4.5/5");
		lblNewLabel_9_2_1_2.setBounds(239, 175, 67, 21);
		frame.getContentPane().add(lblNewLabel_9_2_1_2);
		
		JLabel lblNewLabel_9_2_1_3 = new JLabel("Feedback:");
		lblNewLabel_9_2_1_3.setBounds(107, 216, 67, 21);
		frame.getContentPane().add(lblNewLabel_9_2_1_3);
		
		textField = new JTextField();
		textField.setColumns(10);
		textField.setBounds(239, 217, 75, 41);
		frame.getContentPane().add(textField);
		
		JButton btnNewButton_2 = new JButton("Submit");
		btnNewButton_2.setFont(new Font("Tahoma", Font.PLAIN, 9));
		btnNewButton_2.setBounds(242, 268, 75, 21);
		frame.getContentPane().add(btnNewButton_2);
		
		JButton btnNewButton_1_1 = new JButton("Back");
		btnNewButton_1_1.setBounds(55, 315, 75, 21);
		frame.getContentPane().add(btnNewButton_1_1);
		
		JLabel lblNewLabel_10_1 = new JLabel("");
		lblNewLabel_10_1.setIcon(new ImageIcon("C:\\Users\\reddy\\Pictures\\Saved Pictures\\c1.jpg"));
		lblNewLabel_10_1.setBounds(377, 129, 150, 102);
		frame.getContentPane().add(lblNewLabel_10_1);
		frame.setVisible(true);
		btnNewButton_1_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frame.getContentPane().setVisible(false);
				frame.dispose();
				h.main(null);
			}
		});

		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JOptionPane.showMessageDialog(null,"Feedback Success");
			}
		});
		
	}

}
